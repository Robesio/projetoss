const products = [
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batatinha",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },
    {
        "name": "Batata grande",
        "image_path": "https://www.prezunic.com.br/cms/wp-content/uploads/2020/11/dia-da-feira-batata-recheada-com-requeijao-e-bacon-nota-469x459.png",
        "disp": 4,
        "price": 22.55
    },

]