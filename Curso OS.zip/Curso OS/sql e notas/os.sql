DROP DATABASE IF EXISTS dbinfox;
CREATE DATABASE dbinfox;
USE dbinfox;
CREATE TABLE tbusuarios(
    iduser INT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL,
    fone VARCHAR(15),
    login VARCHAR(15) NOT NULL UNIQUE,
    senha VARCHAR(15) NOT NULL,
    perfil VARCHAR(20) NOT NULL
); 

INSERT INTO tbusuarios(iduser,usuario,fone,login,senha) VALUES
(1,'Robésio','199999999','robesio','12'),
(2,'josé de Assis','1998998989','admin','admin'),
(3,'Usuário comum','1998998989','comum','comum');


update tbusuarios set perfil='admin' where iduser=1;
update tbusuarios set perfil='admin' where iduser=2;
update tbusuarios set perfil='user' where iduser=3;

CREATE TABLE tbclientes(
    idcli INT PRIMARY KEY auto_increment,
    nomecli VARCHAR(50) NOT NULL,
    endcli VARCHAR(100),
    fonecli VARCHAR(50) NOT NULL,
    emailcli VARCHAR(50) NOT NULL
); 

INSERT INTO tbclientes(nomecli,endcli,fonecli,emailcli) VALUES
('Robesio do Carmo','Rua Souza, 490','7777-7777','dev@dev.com'),
('Linux torvalds','Rua tux, 2021','192222222','linux@linux.com'),
('Lula presidente','Rua guimarões, 888','1111-1111','lula@lula.com'),
('Lara larinha','Rua laraa, 900','3333-3333','lara@lara.com'),
('Reginaldo Silva','Rua paraná, 890','4444-4444','regis@regis.com'),
('Amanda Melo','Rua amazona, 765','5555-5555','amanda@amanda.com'),
('Ana Maria','Rua bahia, 321','6666-6666','ana@ana.com'),
('Fernanda Nogueira','Rua pernambuco, 2015','7777-7777','fe@fe.com'),
('Fatima silva','Rua amapa, 555','8888-8888','fatima@fatima.com'),
('Fabiana aninha','Rua piaui, 345','9999-9999','fabiana@fabiana.com'),
('Raul fabricio','Rua goiais, 21','0000-0000','raul@raul.com'),
('Daniel perreira','Rua jucati, 123','192222222','daniel@daniel.com'),
('Danilo souza','Rua alegre, 987','1234-5789','danilo@danilo.com'),
('Divid eseis','Rua jaguar, 667','5645-4224','divid@divid.com'),
('Erik murilo','Rua pedreira, 2424','2424-2424','erik@erik.com'),
('Erlan ferreira','Rua sitio, 444','1111-1111','erlan@erlan.com');

CREATE TABLE tbos(
    os INT PRIMARY KEY auto_increment,
    data_os TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    tipo VARCHAR(15) NOT NULL,
    situacao VARCHAR(20) NOT NULL,
    equipamento VARCHAR(150) NOT NULL,
    defeito VARCHAR(150) NOT NULL,
    servico VARCHAR(150),
    tecnico VARCHAR(30), 
    valor DECIMAL(10,2),
    idcli INT NOT NULL,
    FOREIGN KEY(idcli) REFERENCES tbclientes(idcli)
); 

INSERT INTO tbos(tipo,situacao,equipamento,defeito,servico,tecnico,valor,idcli) VALUES
('Orçamento','Abandonado pelo cliente','PC','monitor trincado','trocar monitor','ro',87.50,1);

SELECT 
O.os,equipamento,defeito,servico,valor,
C.nomecli,fonecli FROM tbos AS O INNER JOIN tbclientes AS C ON (O.idcli = C.idcli);


describe tbusuarios;
describe tbclientes;
describe tbos;
SELECT * FROM tbclientes;
SELECT * FROM tbusuarios;
SELECT * FROM tbos;

